/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_242(unsigned x)
{
    return x + 2445773128U;
}

void setval_147(unsigned *p)
{
    *p = 2420672616U;
}

unsigned addval_450(unsigned x)
{
    return x + 2421701657U;
}

void setval_180(unsigned *p)
{
    *p = 1358799865U;
}

unsigned getval_209()
{
    return 3284633928U;
}

unsigned getval_116()
{
    return 1086558296U;
}

unsigned addval_363(unsigned x)
{
    return x + 3284633928U;
}

void setval_192(unsigned *p)
{
    *p = 3251079496U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_320()
{
    return 3531919745U;
}

unsigned addval_175(unsigned x)
{
    return x + 3284306743U;
}

unsigned getval_449()
{
    return 3229926029U;
}

unsigned addval_462(unsigned x)
{
    return x + 3380920969U;
}

void setval_235(unsigned *p)
{
    *p = 3372798345U;
}

unsigned getval_246()
{
    return 3372794569U;
}

unsigned getval_352()
{
    return 3286276424U;
}

unsigned getval_149()
{
    return 2425405961U;
}

unsigned addval_291(unsigned x)
{
    return x + 3674784393U;
}

void setval_486(unsigned *p)
{
    *p = 3286272332U;
}

unsigned addval_258(unsigned x)
{
    return x + 3526939019U;
}

void setval_384(unsigned *p)
{
    *p = 3465141182U;
}

void setval_367(unsigned *p)
{
    *p = 3531919817U;
}

unsigned getval_440()
{
    return 3247492745U;
}

unsigned addval_210(unsigned x)
{
    return x + 3229926027U;
}

void setval_347(unsigned *p)
{
    *p = 3286272328U;
}

unsigned getval_181()
{
    return 3232026249U;
}

unsigned getval_416()
{
    return 3456719826U;
}

unsigned addval_208(unsigned x)
{
    return x + 3375944077U;
}

unsigned getval_248()
{
    return 3281047177U;
}

unsigned addval_340(unsigned x)
{
    return x + 3515442624U;
}

unsigned addval_119(unsigned x)
{
    return x + 3381969545U;
}

void setval_409(unsigned *p)
{
    *p = 3269495112U;
}

unsigned getval_103()
{
    return 3223376269U;
}

unsigned getval_350()
{
    return 3285100875U;
}

void setval_277(unsigned *p)
{
    *p = 3234123401U;
}

unsigned getval_132()
{
    return 3353381192U;
}

void setval_390(unsigned *p)
{
    *p = 3372273289U;
}

void setval_451(unsigned *p)
{
    *p = 2464188744U;
}

unsigned getval_359()
{
    return 3286272328U;
}

unsigned getval_499()
{
    return 3281047937U;
}

unsigned addval_395(unsigned x)
{
    return x + 3286272264U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
